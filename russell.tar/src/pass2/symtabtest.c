main()
{
	mknode(BLOCKDENOTATION,
			mklist( mknode(DECLARATION,
							mknode(LETTERID, stt_enter("first", 6), NIL),
							NIL,
							NIL),
					mknode(DECLARATION,
							mknode(LETTERID, stt_enter("second", 7), NIL),
							NIL,
							NIL),
					mknode(DECLARATION,
							mknode(LETTERID, stt_enter("second", 7), NIL),
							NIL,
							NIL)),
			mklist( 

}
