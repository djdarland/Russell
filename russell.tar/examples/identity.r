func[x: val T; T: type{}] { x }

