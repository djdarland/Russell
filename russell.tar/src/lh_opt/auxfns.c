
int eq (x, y)

int x, y;

{
	return (x == y);
}
