# include "consnodes.h"
tmp(p)
{
    return(cn_tail(p));
}
